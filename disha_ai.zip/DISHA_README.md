# Disha AI companion - DEATH DEVELOPMENT

Independent module (`cogs/disha/`). It only reads messages in servers where Disha is enabled and has **no tools**:
it cannot ban/kick/mute/delete or change anything, and Antinuke / Security / other cogs are not modified.
The installer adds 4 small things only (each edited file gets a `.pre_disha` backup).

## Install (AWS)
```
cd ~ && unzip -o disha_ai.zip -d disha_ai && python3 disha_ai/install_disha.py ~/V50/botfast
nano ~/V50/botfast/.env          # DISHA_API_KEY=...   (free key: console.groq.com; GROQ_API_KEY also works)
sudo apt install -y ffmpeg       # only for voice replies
sudo systemctl restart deathbot
```
Then in Discord: `.disha enable` (adds the current channel) - done.

## Commands (admins need Manage Server)
| command | what |
|---|---|
| `disha enable` / `disable` | turn on/off (enable adds the current channel) |
| `disha channel add\|remove\|list [#ch]` | channels where she chats on her own |
| `disha personality [text\|reset]` | style note (safety rules can't be overridden) |
| `disha voice on\|off`, `disha gif on\|off` | voice notes / GIFs |
| `disha chance <0-60>` | % chance she joins a chat uninvited (default 12) |
| `disha status`, `disha mood` | state |
| `disha memory [@user]`, `disha forget [@user]` | see / clear memory (members: own only) |
| `disha forgetall confirm`, `disha reset confirm` | wipe server memory / reset config |

She answers anywhere when mentioned, replied to, or called "Disha"; uninvited only in the chat channels.

## How it behaves
* **Frequency**: uninvited replies are probabilistic + cooldowns (25 s per person, 12 s per channel, max 6 per 10 min);
  follow-ups within 75 s of her reply are answered; people talking to each other are left alone.
* **Memory**: short-term = last exchanges per person (6 h) + channel context; long-term = short facts per person
  (`db/disha.db`, per server, max 80). Secrets/numbers/e-mails/self-harm details are never stored.
* **Moods**: happy sad angry excited romantic funny sarcastic caring savage - chosen per reply, kept per channel,
  fade to happy after 30 min; they change tone, emojis and GIF search.
* **GIFs** (Giphy): at most one per 2 min and per 3 replies, never the same GIF twice per channel.
* **Voice**: voice messages are transcribed (Groq Whisper) and answered; she sometimes answers with a voice note.
* **Safety**: chat text is treated as data (prompt-injection rules), outputs are scrubbed (no pings, invites, keys),
  replies never ping, bots/webhooks/self ignored, blacklist + ignore lists respected, per-user spam mute,
  25 AI calls/min/server, API retries with timeouts, friendly fallback when the AI is down.

## Env
`DISHA_API_KEY` (or `GROQ_API_KEY`) required - optional: `DISHA_API_BASE`, `DISHA_MODEL`, `DISHA_STT_MODEL`,
`DISHA_MAX_CONCURRENCY`, `GIPHY_API_KEY`.

## Tests
`python3 disha_tests/test_disha.py` runs 77 checks with fake Discord/LLM/DB (no network needed).
