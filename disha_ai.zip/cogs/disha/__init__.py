"""Disha AI companion (independent module). Loaded from cogs/__init__.py, never edits other modules."""
from .cog import Disha

__all__ = ["Disha"]
