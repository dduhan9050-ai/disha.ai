"""Disha AI companion - discord glue.

Self-contained cog: it only listens to messages (guilds where Disha is enabled) and exposes the `disha` command
group.  It never touches antinuke / security code and cannot run moderation actions (it has no tools at all).
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from collections import deque
from typing import Optional

import aiosqlite
import discord
from discord.ext import commands

from utils.Tools import blacklist_check, ignore_check, get_ignore_data

from . import brain
from .llm import LLM, LLMError
from .media import giphy_key, giphy_search, has_ffmpeg, send_voice_message, synth_voice
from .store import Store

log = logging.getLogger("disha")

TICK = "<:emoji_4:1566043104551768114>"
CROSS = "<a:emoji_38:1567096105299214336>"
NAME_RE = re.compile(r"\bdisha+\b", re.I)
FALLBACKS = (
    "arre yaar thoda brain freeze ho gaya 😵 ek baar aur bolo?",
    "network ne dhoka de diya 🥲 thodi der baad try karo",
    "oops, meri soch atak gayi... phir se bolo?",
)
NONE_MENTIONS = discord.AllowedMentions.none()


def _onoff(value: str) -> Optional[bool]:
    v = (value or "").lower()
    if v in ("on", "enable", "enabled", "yes", "true", "1"):
        return True
    if v in ("off", "disable", "disabled", "no", "false", "0"):
        return False
    return None


class Disha(commands.Cog, name="Disha"):
    """Disha AI companion."""

    def __init__(self, bot) -> None:
        self.bot = bot
        self.store = Store()
        self.llm = LLM(lambda: self.bot.session)
        self.pacer = brain.Pacer()
        self.gate = brain.MediaGate()
        self._buf: dict[int, deque] = {}            # channel -> recent (msg_id, name, text)
        self._buf_ts: dict[int, float] = {}
        self._mood: dict[int, brain.MoodState] = {}
        self._locks: dict[int, asyncio.Lock] = {}
        self._tasks: set[asyncio.Task] = set()
        self._sem = asyncio.Semaphore(max(1, int(os.getenv("DISHA_MAX_CONCURRENCY", "4"))))
        self._block_cache: dict[tuple, tuple[float, bool]] = {}
        self._fail_notice: dict[int, float] = {}
        self._prune_task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------- lifecycle
    async def cog_load(self) -> None:
        await self.store.init()
        self._prune_task = asyncio.create_task(self._prune_loop())

    async def cog_unload(self) -> None:
        if self._prune_task:
            self._prune_task.cancel()
        for t in list(self._tasks):
            t.cancel()
        await self.store.close()

    async def _prune_loop(self) -> None:
        while True:
            await asyncio.sleep(600)
            now = time.monotonic()
            self.pacer.prune(now)
            for ch in [c for c, ts in self._buf_ts.items() if now - ts > 3600]:
                self._buf.pop(ch, None)
                self._buf_ts.pop(ch, None)
                self._mood.pop(ch, None)
            for ch in [c for c, lk in self._locks.items() if not lk.locked() and c not in self._buf]:
                self._locks.pop(ch, None)
            self._block_cache = {k: v for k, v in self._block_cache.items() if v[0] > now}

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _send_opts() -> dict:
        # this bot rewrites plain text sends into Components V2 cards; chat must stay plain text (GIF links embed)
        return {"legacy_embed": True} if getattr(discord.abc.Messageable.send, "_deathbot_v2_patched", False) else {}

    async def _send(self, message: discord.Message, content: str, reply: bool) -> Optional[discord.Message]:
        opts = self._send_opts()
        try:
            if reply:
                return await message.reply(content, allowed_mentions=NONE_MENTIONS, **opts)
            return await message.channel.send(content, allowed_mentions=NONE_MENTIONS, **opts)
        except discord.HTTPException:
            try:
                return await message.channel.send(content, allowed_mentions=NONE_MENTIONS, **opts)
            except discord.HTTPException:
                return None

    @staticmethod
    def _in_ambient(cfg, channel) -> bool:
        return channel.id in cfg.channels or getattr(channel, "parent_id", None) in cfg.channels

    @staticmethod
    def _voice_attachment(message: discord.Message):
        for a in message.attachments:
            try:
                if a.is_voice_message():
                    return a
            except AttributeError:
                if (a.content_type or "").startswith("audio/ogg") and getattr(a, "duration", None):
                    return a
        return None

    async def _blocked(self, guild_id: int, user_id: int, channel_id: int) -> bool:
        """Respect the bot's blacklist + `ignore` settings (same rules as the Mention cog)."""
        now = time.monotonic()
        hit = self._block_cache.get((guild_id, user_id))
        if hit and hit[0] > now:
            blocked = hit[1]
        else:
            blocked = False
            try:
                async with aiosqlite.connect("db/block.db") as db:
                    for sql, arg in (("SELECT 1 FROM guild_blacklist WHERE guild_id = ?", guild_id),
                                     ("SELECT 1 FROM user_blacklist WHERE user_id = ?", user_id)):
                        cur = await db.execute(sql, (arg,))
                        if await cur.fetchone():
                            blocked = True
                            break
            except Exception:
                blocked = False
            self._block_cache[(guild_id, user_id)] = (now + 60, blocked)
        if blocked:
            return True
        try:
            ign = await get_ignore_data(guild_id)
            return str(user_id) in ign["user"] or str(channel_id) in ign["channel"]
        except Exception:
            return False

    def _remember_chat(self, channel_id: int, msg_id: Optional[int], name: str, text: str) -> None:
        dq = self._buf.setdefault(channel_id, deque(maxlen=16))
        dq.append((msg_id, name, text[:220]))
        self._buf_ts[channel_id] = time.monotonic()

    # --------------------------------------------------------------- listener
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        # ---- fast exits: nothing below runs for bots, DMs or servers where Disha is off
        if message.author.bot or message.webhook_id or message.guild is None:
            return
        cfg = self.store.cfgs.get(message.guild.id)
        if cfg is None or not cfg.enabled:
            return
        me = message.guild.me
        if me is None:
            return
        channel = message.channel
        content = message.content or ""
        uid = self.bot.user.id
        if content.strip() in (f"<@{uid}>", f"<@!{uid}>"):          # bare ping = prefix card (Mention cog)
            return

        ambient_ok = self._in_ambient(cfg, channel)
        replied_to_me = False
        ref = message.reference
        if ref is not None and isinstance(ref.resolved, discord.Message):
            replied_to_me = ref.resolved.author.id == uid
        directed = (self.bot.user in message.mentions) or replied_to_me or bool(NAME_RE.search(content))
        voice_att = self._voice_attachment(message)
        if not directed and not ambient_ok:
            return
        if not content.strip() and voice_att is None:
            return
        if not channel.permissions_for(me).send_messages:
            return

        # ---- never answer normal bot commands
        try:
            ctx = await self.bot.get_context(message)
            if ctx.valid:
                return
        except Exception:
            pass

        text = message.clean_content or ""
        text = re.sub(r"@" + re.escape(me.display_name), "", text, flags=re.I)
        text = brain.sanitize_in(text)
        speaker = brain.clean_name(message.author.display_name)
        if text:
            self._remember_chat(channel.id, message.id, speaker, text)
        self.pacer.human_spoke(channel.id)

        now = time.monotonic()
        if directed:
            if not self.pacer.allow_direct(channel.id, message.author.id, now):
                return
        else:
            if voice_att is None and len(text) < 4:
                return
            if ref is not None and not replied_to_me:                  # people talking to each other
                return
            if any((not m.bot) and m.id != message.author.id for m in message.mentions):
                return
            if voice_att is None and not re.search(r"[A-Za-z\u0900-\u097f]{2}", text):
                return
            p = self.pacer.ambient_probability(cfg.chance, text, channel.id, message.author.id, now,
                                               voice=voice_att is not None)
            if not self.pacer.allow_ambient(channel.id, message.author.id, now, p):
                return

        if await self._blocked(message.guild.id, message.author.id, channel.id):
            return
        if not self.pacer.guild_ok(message.guild.id, now):
            return
        if not self.llm.available:
            return

        task = asyncio.create_task(self._respond(message, cfg, text, directed, voice_att))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _chat_typing(self, ch, msgs) -> str:
        try:
            async with ch.typing():
                return await self.llm.chat(msgs)
        except discord.HTTPException:                                  # no typing permission etc.
            return await self.llm.chat(msgs)

    # ---------------------------------------------------------------- respond
    async def _respond(self, message, cfg, text, directed, voice_att) -> None:
        ch = message.channel
        lock = self._locks.setdefault(ch.id, asyncio.Lock())
        if lock.locked() and not directed:
            return
        try:
            await asyncio.wait_for(lock.acquire(), 20)
        except asyncio.TimeoutError:
            return
        try:
            async with self._sem:
                await self._respond_locked(message, cfg, text, directed, voice_att)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("disha: unexpected error")
        finally:
            lock.release()

    async def _respond_locked(self, message, cfg, text, directed, voice_att) -> None:
        ch, guild, uid = message.channel, message.guild, message.author.id
        speaker = brain.clean_name(message.author.display_name)
        voice_input = False

        if voice_att is not None:                                      # speech -> text
            transcript = ""
            try:
                if (voice_att.size or 0) <= 8 * 1024 * 1024:
                    transcript = await self.llm.transcribe(await voice_att.read())
            except Exception as e:
                log.warning("disha: transcription failed: %s", type(e).__name__)
            if not transcript:
                if directed:
                    await self._send(message, "voice clear sunai nahi di yaar, ek baar text me bol? 🥲", True)
                return
            text, voice_input = brain.sanitize_in(transcript), True
            self._remember_chat(ch.id, message.id, speaker, "🎤 " + text)
        if not text:
            return

        rows = await self.store.facts(guild.id, uid)
        picked = brain.pick_facts(rows, text, 6)
        history = await self.store.recent_turns(guild.id, uid, 6)
        mstate = self._mood.setdefault(ch.id, brain.MoodState())
        now = time.monotonic()
        hint = brain.detect_mood_hint(text)
        mood = mstate.current(now)
        gif_ok = cfg.gif and bool(giphy_key())
        voice_ok = cfg.voice and has_ffmpeg() and (directed or voice_input)
        suspicious = brain.looks_like_injection(text)

        system = brain.build_system_prompt(mood=mood, mood_hint=hint, speaker=speaker, facts=[f for _, f in picked],
                                           custom=cfg.personality, directed=directed, voice_input=voice_input,
                                           gif_ok=gif_ok, voice_ok=voice_ok, suspicious=suspicious)
        buf = [(n, t) for mid, n, t in self._buf.get(ch.id, ()) if mid != message.id]
        block = brain.build_user_block(channel=getattr(ch, "name", "chat"), buffer=buf, speaker=speaker, text=text)
        msgs = [{"role": "system", "content": system},
                *({"role": r, "content": c} for r, c in history if r in ("user", "assistant")),
                {"role": "user", "content": block}]

        try:
            raw = await self._chat_typing(ch, msgs)
        except LLMError as e:
            log.warning("disha: LLM failed: %s", e)
            if directed and time.monotonic() - self._fail_notice.get(ch.id, 0) > 60:
                self._fail_notice[ch.id] = time.monotonic()
                await self._send(message, FALLBACKS[int(time.time()) % len(FALLBACKS)], True)
            return

        out = brain.parse_output(raw)
        reply = brain.sanitize_out(out.reply)
        if not reply or (out.skip and not directed):
            return
        if not self.store.cfg(guild.id).enabled:                       # disabled while we were thinking
            return

        now = time.monotonic()
        mstate.set(out.mood or hint, now)
        mood = mstate.current(now)

        # ---- memory (short + long term)
        await self.store.add_turn(guild.id, uid, "user", text)
        await self.store.add_turn(guild.id, uid, "assistant", reply)
        if not suspicious:
            new_facts = brain.clean_facts(out.remember)
            if new_facts:
                await self.store.add_facts(guild.id, uid, new_facts)
        await self.store.touch([i for i, _ in picked])

        # ---- delivery: voice note, else text (+ GIF)
        sent = False
        if voice_ok and self.gate.want_voice(ch.id, now, voice_input, len(reply), out.voice):
            syn = await synth_voice(reply)
            if syn:
                sent = await send_voice_message(self.bot.session, self.bot.http.token, ch.id, syn[0], syn[1],
                                                reply_to=message.id if directed else None)
                if sent:
                    self.gate.used_voice(ch.id, now)
        if not sent:
            gif_url = None
            if gif_ok and self.gate.want_gif(ch.id, now, bool(out.gif), mood):
                results = await giphy_search(self.bot.session, brain.gif_query(out.gif, mood, self.gate.rng))
                pick = self.gate.pick(ch.id, results)
                if pick:
                    gif_url = pick[1]
                    self.gate.used_gif(ch.id, pick[0], now)
            newer = bool(self._buf.get(ch.id)) and self._buf[ch.id][-1][0] != message.id
            await self._send(message, reply + (f"\n{gif_url}" if gif_url else ""), directed or newer)
        self.pacer.mark_reply(ch.id, uid, time.monotonic(), ambient=not directed)
        self._remember_chat(ch.id, None, "Disha", reply)

    # --------------------------------------------------------------- commands
    async def _say(self, ctx: commands.Context, text: str):
        return await ctx.send(text, allowed_mentions=NONE_MENTIONS)

    @commands.group(name="disha", aliases=["dishaai"], invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def disha(self, ctx: commands.Context):
        """Disha AI companion."""
        p = ctx.clean_prefix
        await self._say(ctx, (
            "## Disha AI\n"
            f"`{p}disha enable` / `disable` - turn Disha on or off\n"
            f"`{p}disha channel add|remove|list [#channel]` - channels where she chats on her own\n"
            f"`{p}disha personality [text|reset]` - style note for this server\n"
            f"`{p}disha voice on|off` / `{p}disha gif on|off` - voice notes and GIFs\n"
            f"`{p}disha chance <0-60>` - how often she joins in uninvited (%)\n"
            f"`{p}disha status` / `{p}disha mood`\n"
            f"`{p}disha memory [@user]` - what she remembers  |  `{p}disha forget [@user]` - clear it\n"
            f"`{p}disha forgetall confirm` - clear every memory of this server\n"
            f"`{p}disha reset confirm` - reset Disha's configuration\n"
            "Talk to her by mentioning her, replying to her, or saying \"Disha\"."))

    @disha.command(name="enable", aliases=["on"])
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_enable(self, ctx: commands.Context):
        cfg = self.store.cfg(ctx.guild.id)
        cfg.enabled = True
        if not cfg.channels:
            cfg.channels.add(ctx.channel.id)
        await self.store.save_cfg(cfg)
        note = "" if self.llm.available else f"\n{CROSS} No API key found - set `DISHA_API_KEY` (or `GROQ_API_KEY`) in `.env` and restart."
        await self._say(ctx, f"{TICK} Disha is **on**. She chats on her own in " +
                        ", ".join(f"<#{c}>" for c in sorted(cfg.channels)) +
                        " and answers when mentioned/replied to anywhere." + note)

    @disha.command(name="disable", aliases=["off"])
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_disable(self, ctx: commands.Context):
        cfg = self.store.cfg(ctx.guild.id)
        cfg.enabled = False
        await self.store.save_cfg(cfg)
        await self._say(ctx, f"{TICK} Disha is **off**. Memories are kept.")

    @disha.group(name="channel", aliases=["channels"], invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_channel(self, ctx: commands.Context):
        await self.d_channel_list(ctx)

    @d_channel.command(name="list")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def d_channel_list(self, ctx: commands.Context):
        cfg = self.store.cfg(ctx.guild.id)
        await self._say(ctx, "Disha chats on her own in: " + (", ".join(f"<#{c}>" for c in sorted(cfg.channels))
                        if cfg.channels else "no channel yet (use `disha channel add`)"))

    @d_channel.command(name="add")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def d_channel_add(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        cfg = self.store.cfg(ctx.guild.id)
        if len(cfg.channels) >= 15:
            return await self._say(ctx, f"{CROSS} Max 15 channels.")
        cfg.channels.add(channel.id)
        await self.store.save_cfg(cfg)
        await self._say(ctx, f"{TICK} Disha can now chat in {channel.mention}.")

    @d_channel.command(name="remove", aliases=["delete"])
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def d_channel_remove(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        cfg = self.store.cfg(ctx.guild.id)
        cfg.channels.discard(channel.id)
        await self.store.save_cfg(cfg)
        await self._say(ctx, f"{TICK} Removed {channel.mention}.")

    @disha.command(name="personality", aliases=["persona"])
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_personality(self, ctx: commands.Context, *, text: Optional[str] = None):
        cfg = self.store.cfg(ctx.guild.id)
        if not text:
            return await self._say(ctx, "Personality note: " + (f"```{cfg.personality}```" if cfg.personality
                                   else "none (default Disha)"))
        if text.strip().lower() in ("reset", "default", "clear"):
            cfg.personality = ""
            await self.store.save_cfg(cfg)
            return await self._say(ctx, f"{TICK} Personality reset to default Disha.")
        cfg.personality = brain.sanitize_in(text, 500)
        await self.store.save_cfg(cfg)
        await self._say(ctx, f"{TICK} Personality note saved. (Safety rules always stay on.)")

    async def _toggle(self, ctx, state: str, attr: str, label: str, needs: str = ""):
        val = _onoff(state)
        cfg = self.store.cfg(ctx.guild.id)
        if val is None:
            return await self._say(ctx, f"{label} is **{'on' if getattr(cfg, attr) else 'off'}**. "
                                        f"Use `{ctx.clean_prefix}disha {attr} on|off`.")
        setattr(cfg, attr, val)
        await self.store.save_cfg(cfg)
        warn = f"\n{CROSS} {needs}" if val and needs else ""
        await self._say(ctx, f"{TICK} {label} **{'on' if val else 'off'}**.{warn}")

    @disha.command(name="voice")
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_voice(self, ctx: commands.Context, state: str = ""):
        await self._toggle(ctx, state, "voice", "Voice replies",
                           "" if has_ffmpeg() else "`ffmpeg` is not installed on the server (`sudo apt install ffmpeg`).")

    @disha.command(name="gif", aliases=["gifs"])
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_gif(self, ctx: commands.Context, state: str = ""):
        await self._toggle(ctx, state, "gif", "GIF replies",
                           "" if giphy_key() else "`GIPHY_API_KEY` is not set in `.env`.")

    @disha.command(name="chance")
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_chance(self, ctx: commands.Context, percent: Optional[int] = None):
        cfg = self.store.cfg(ctx.guild.id)
        if percent is None:
            return await self._say(ctx, f"Disha joins conversations uninvited about **{cfg.chance}%** of the time.")
        cfg.chance = max(0, min(60, percent))
        await self.store.save_cfg(cfg)
        await self._say(ctx, f"{TICK} Uninvited-reply chance set to **{cfg.chance}%**.")

    @disha.command(name="status")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_status(self, ctx: commands.Context):
        cfg = self.store.cfg(ctx.guild.id)
        n, users = await self.store.stats(ctx.guild.id)
        onoff = lambda b: "on" if b else "off"
        await self._say(ctx, (
            "## Disha status\n"
            f"**Enabled:** {onoff(cfg.enabled)}\n"
            f"**Chat channels:** {', '.join(f'<#{c}>' for c in sorted(cfg.channels)) or 'none'}\n"
            f"**Voice replies:** {onoff(cfg.voice)} (ffmpeg {'found' if has_ffmpeg() else 'missing'})\n"
            f"**GIFs:** {onoff(cfg.gif)} (Giphy key {'set' if giphy_key() else 'missing'})\n"
            f"**Uninvited chance:** {cfg.chance}%\n"
            f"**Personality note:** {'custom' if cfg.personality else 'default'}\n"
            f"**AI backend:** {'ready' if self.llm.available else 'no API key'} · `{self.llm.model}`\n"
            f"**Memory:** {n} facts about {users} people"))

    @disha.command(name="mood")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_mood(self, ctx: commands.Context):
        st = self._mood.get(ctx.channel.id)
        mood = st.current(time.monotonic()) if st else brain.BASE_MOOD
        await self._say(ctx, f"Disha's mood in this channel: **{mood}** {brain.MOOD_INFO[mood]['emojis'].split()[0]}")

    @disha.command(name="memory", aliases=["memories"])
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_memory(self, ctx: commands.Context, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if member.id != ctx.author.id and not ctx.author.guild_permissions.manage_guild:
            return await self._say(ctx, f"{CROSS} Only admins can view someone else's memory.")
        rows = await self.store.facts(ctx.guild.id, member.id)
        if not rows:
            return await self._say(ctx, f"I don't remember anything about **{brain.clean_name(member.display_name)}** yet.")
        lines = "\n".join(f"- {brain.sanitize_out(f, 130)}" for _, f, _, _ in rows[:12])
        await self._say(ctx, f"## What I remember about {brain.clean_name(member.display_name)}\n{lines}"
                             + (f"\n…and {len(rows) - 12} more" if len(rows) > 12 else ""))

    @disha.command(name="forget", aliases=["clearmemory"])
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_forget(self, ctx: commands.Context, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if member.id != ctx.author.id and not ctx.author.guild_permissions.manage_guild:
            return await self._say(ctx, f"{CROSS} Only admins can clear someone else's memory.")
        n = await self.store.clear_user(ctx.guild.id, member.id)
        await self._say(ctx, f"{TICK} Forgot everything about **{brain.clean_name(member.display_name)}** ({n} facts).")

    @disha.command(name="forgetall")
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_forgetall(self, ctx: commands.Context, confirm: str = ""):
        if confirm.lower() != "confirm":
            return await self._say(ctx, f"{CROSS} This wipes every memory in this server. Run "
                                        f"`{ctx.clean_prefix}disha forgetall confirm` to continue.")
        n = await self.store.clear_guild(ctx.guild.id)
        await self._say(ctx, f"{TICK} Wiped {n} facts.")

    @disha.command(name="reset")
    @commands.has_permissions(manage_guild=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def d_reset(self, ctx: commands.Context, confirm: str = ""):
        if confirm.lower() != "confirm":
            return await self._say(ctx, f"{CROSS} This resets Disha's settings (memories are kept). Run "
                                        f"`{ctx.clean_prefix}disha reset confirm` to continue.")
        await self.store.reset_cfg(ctx.guild.id)
        await self._say(ctx, f"{TICK} Disha's configuration was reset (she is now off).")
