"""OpenAI-compatible chat + speech-to-text client (Groq by default).

Env (never hard-code keys):
    DISHA_API_KEY   (falls back to GROQ_API_KEY, then OPENAI_API_KEY)
    DISHA_API_BASE  default https://api.groq.com/openai/v1
    DISHA_MODEL     default llama-3.3-70b-versatile
    DISHA_STT_MODEL default whisper-large-v3-turbo
"""
from __future__ import annotations

import asyncio
import os
import random
from typing import Any, Optional

import aiohttp

TOTAL_TIMEOUT = 25.0
MAX_RETRIES = 2


class LLMError(Exception):
    pass


def _env(*names: str, default: str = "") -> str:
    for n in names:
        v = os.getenv(n, "").strip()
        if v:
            return v
    return default


class LLM:
    def __init__(self, session_getter) -> None:
        self._session_getter = session_getter

    # read env on every use so a restart with a new .env is all that is needed
    @property
    def key(self) -> str:
        return _env("DISHA_API_KEY", "GROQ_API_KEY", "OPENAI_API_KEY")

    @property
    def base(self) -> str:
        return _env("DISHA_API_BASE", default="https://api.groq.com/openai/v1").rstrip("/")

    @property
    def model(self) -> str:
        return _env("DISHA_MODEL", default="llama-3.3-70b-versatile")

    @property
    def stt_model(self) -> str:
        return _env("DISHA_STT_MODEL", default="whisper-large-v3-turbo")

    @property
    def available(self) -> bool:
        return bool(self.key)

    async def _post(self, url: str, *, json_body: Optional[dict] = None,
                    form: Optional[aiohttp.FormData] = None) -> tuple[int, Any, Optional[float]]:
        session = self._session_getter()
        headers = {"Authorization": f"Bearer {self.key}"}
        async with session.post(url, json=json_body, data=form, headers=headers,
                                timeout=aiohttp.ClientTimeout(total=TOTAL_TIMEOUT)) as resp:
            try:
                data = await resp.json(content_type=None)
            except Exception:
                data = await resp.text()
            ra = resp.headers.get("Retry-After")
            return resp.status, data, float(ra) if ra and ra.replace(".", "", 1).isdigit() else None

    async def _with_retry(self, make_call):
        last = "unknown error"
        for attempt in range(MAX_RETRIES + 1):
            try:
                status, data, retry_after = await make_call()
            except (asyncio.TimeoutError, aiohttp.ClientError) as e:
                status, data, retry_after = 0, None, None
                last = type(e).__name__
            else:
                if status == 200:
                    return data
                last = f"HTTP {status}"
                if status not in (408, 429) and status < 500:
                    msg = ""
                    if isinstance(data, dict):
                        msg = str((data.get("error") or {}).get("message", ""))[:160]
                    raise LLMError(f"{last}: {msg}".strip(": "))      # 4xx: retrying will not help
            if attempt < MAX_RETRIES:
                delay = min(retry_after or (0.8 * 2 ** attempt), 6.0) + random.random() * 0.4
                await asyncio.sleep(delay)
        raise LLMError(last)

    async def chat(self, messages: list[dict], *, json_mode: bool = True, max_tokens: int = 380,
                   temperature: float = 0.9) -> str:
        if not self.available:
            raise LLMError("no API key configured")
        body = {"model": self.model, "messages": messages, "max_tokens": max_tokens,
                "temperature": temperature, "top_p": 0.95}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        url = f"{self.base}/chat/completions"
        try:
            data = await self._with_retry(lambda: self._post(url, json_body=body))
        except LLMError as e:
            if json_mode and str(e).startswith("HTTP 400"):        # provider without json mode -> plain retry
                body.pop("response_format", None)
                data = await self._with_retry(lambda: self._post(url, json_body=body))
            else:
                raise
        try:
            return (data["choices"][0]["message"]["content"] or "").strip()
        except Exception as e:
            raise LLMError("bad response shape") from e

    async def transcribe(self, audio: bytes, filename: str = "voice-message.ogg") -> str:
        if not self.available:
            raise LLMError("no API key configured")

        def make() -> aiohttp.FormData:
            form = aiohttp.FormData()
            form.add_field("file", audio, filename=filename, content_type="audio/ogg")
            form.add_field("model", self.stt_model)
            form.add_field("response_format", "json")
            return form

        url = f"{self.base}/audio/transcriptions"
        data = await self._with_retry(lambda: self._post(url, form=make()))
        text = (data.get("text") if isinstance(data, dict) else "") or ""
        return text.strip()
