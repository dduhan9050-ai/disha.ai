"""GIF search (Giphy), text-to-speech and Discord voice-message sending."""
from __future__ import annotations

import asyncio
import base64
import io
import json
import math
import os
import re
import shutil
from typing import Optional

import aiohttp

GIPHY_URL = "https://api.giphy.com/v1/gifs/search"
DISCORD_API = "https://discord.com/api/v10"
VOICE_FLAG = 1 << 13        # IS_VOICE_MESSAGE


def giphy_key() -> str:
    return os.getenv("GIPHY_API_KEY", "").strip()


def has_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


async def giphy_search(session: aiohttp.ClientSession, query: str, limit: int = 20) -> list[tuple[str, str]]:
    key = giphy_key()
    if not key or not query:
        return []
    params = {"api_key": key, "q": query, "limit": str(limit), "rating": "pg-13", "lang": "en"}
    try:
        async with session.get(GIPHY_URL, params=params, timeout=aiohttp.ClientTimeout(total=8)) as r:
            if r.status != 200:
                return []
            data = await r.json(content_type=None)
    except (asyncio.TimeoutError, aiohttp.ClientError, ValueError):
        return []
    out = []
    for item in data.get("data", []):
        gid = item.get("id")
        if gid:
            out.append((gid, f"https://media.giphy.com/media/{gid}/giphy.gif"))
    return out


# ------------------------------------------------------------------------- TTS
_EMOJI_RE = re.compile("[\U00010000-\U0010ffff\u2600-\u27bf\ufe0f]")
_URL_RE = re.compile(r"https?://\S+")


def tts_text(text: str) -> str:
    text = _URL_RE.sub("", text)
    text = _EMOJI_RE.sub("", text)
    text = re.sub(r"[*_`~>|#]+", "", text)
    return re.sub(r"\s+", " ", text).strip()[:280]


def _gtts_mp3(text: str) -> bytes:
    from gtts import gTTS                         # imported lazily: the bot starts even if gTTS is missing
    buf = io.BytesIO()
    gTTS(text, lang="en", tld="co.in").write_to_fp(buf)   # Indian-English voice reads Hinglish naturally
    return buf.getvalue()


async def _run(cmd: list[str], data: bytes, timeout: float = 20.0) -> Optional[bytes]:
    try:
        proc = await asyncio.create_subprocess_exec(*cmd, stdin=asyncio.subprocess.PIPE,
                                                    stdout=asyncio.subprocess.PIPE,
                                                    stderr=asyncio.subprocess.DEVNULL)
        out, _ = await asyncio.wait_for(proc.communicate(data), timeout)
        return out if proc.returncode == 0 and out else None
    except (asyncio.TimeoutError, OSError):
        try:
            proc.kill()
        except Exception:
            pass
        return None


async def synth_voice(text: str) -> Optional[tuple[bytes, float]]:
    """Return (ogg/opus bytes, duration seconds) ready for a Discord voice message, or None."""
    text = tts_text(text)
    if len(text) < 2 or not has_ffmpeg():
        return None
    try:
        mp3 = await asyncio.wait_for(asyncio.to_thread(_gtts_mp3, text), 20)
    except Exception:
        return None
    ogg = await _run(["ffmpeg", "-v", "error", "-i", "pipe:0", "-c:a", "libopus", "-b:a", "32k",
                      "-ar", "48000", "-ac", "1", "-f", "ogg", "pipe:1"], mp3)
    if not ogg:
        return None
    duration = max(1.0, len(text) / 14.0)
    if shutil.which("ffprobe"):
        probe = await _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                            "pipe:0"], ogg, 8)
        try:
            duration = max(0.5, float(probe.decode().strip()))
        except Exception:
            pass
    return ogg, duration


def waveform(seconds: float) -> str:
    n = 64
    return base64.b64encode(bytes(int(40 + 170 * abs(math.sin(i * 0.37 + seconds))) for i in range(n))).decode()


async def send_voice_message(session: aiohttp.ClientSession, token: str, channel_id: int, ogg: bytes,
                             duration: float, reply_to: Optional[int] = None) -> bool:
    """Post a native Discord voice message (flag 8192). Returns False on any failure (caller falls back to text)."""
    payload = {"flags": VOICE_FLAG, "allowed_mentions": {"parse": []},
               "attachments": [{"id": "0", "filename": "voice-message.ogg",
                                "duration_secs": round(duration, 2), "waveform": waveform(duration)}]}
    if reply_to:
        payload["message_reference"] = {"message_id": str(reply_to), "fail_if_not_exists": False}
    form = aiohttp.FormData()
    form.add_field("payload_json", json.dumps(payload), content_type="application/json")
    form.add_field("files[0]", ogg, filename="voice-message.ogg", content_type="audio/ogg")
    try:
        async with session.post(f"{DISCORD_API}/channels/{channel_id}/messages", data=form,
                                headers={"Authorization": f"Bot {token}"},
                                timeout=aiohttp.ClientTimeout(total=20)) as r:
            return r.status in (200, 201)
    except (asyncio.TimeoutError, aiohttp.ClientError):
        return False
