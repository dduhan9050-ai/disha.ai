"""Disha persistent storage (SQLite via aiosqlite, WAL).  One file: db/disha.db

Tables
    disha_config   per-guild settings (enabled, channels, voice, gif, personality, chance)
    disha_facts    long-term memory: short facts per (guild, user)
    disha_history  short-term memory: last exchanges per (guild, user)
Memory is scoped per server on purpose: what someone tells Disha in one server is never shown in another.
"""
from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field
from typing import Iterable

import aiosqlite

DB_PATH = os.getenv("DISHA_DB", "db/disha.db")
MAX_FACTS_PER_USER = 80
MAX_HISTORY_PER_USER = 24


@dataclass
class Cfg:
    guild_id: int
    enabled: bool = False
    channels: set = field(default_factory=set)
    voice: bool = True
    gif: bool = True
    personality: str = ""
    chance: int = 12            # % chance of joining a conversation uninvited


def _norm(fact: str) -> str:
    return " ".join(fact.lower().split())


class Store:
    def __init__(self, path: str = DB_PATH):
        self.path = path
        self._db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()
        self.cfgs: dict[int, Cfg] = {}      # whole config table lives in memory (hot path never touches SQLite)

    # ------------------------------------------------------------------ setup
    async def init(self) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self._db = await aiosqlite.connect(self.path)
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA synchronous=NORMAL")
        await self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS disha_config (
                guild_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0,
                channels TEXT NOT NULL DEFAULT '', voice INTEGER NOT NULL DEFAULT 1,
                gif INTEGER NOT NULL DEFAULT 1, personality TEXT NOT NULL DEFAULT '',
                chance INTEGER NOT NULL DEFAULT 12);
            CREATE TABLE IF NOT EXISTS disha_facts (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                fact TEXT NOT NULL, fkey TEXT NOT NULL, ts REAL NOT NULL, uses INTEGER NOT NULL DEFAULT 0,
                UNIQUE (guild_id, user_id, fkey));
            CREATE INDEX IF NOT EXISTS idx_disha_facts_user ON disha_facts (guild_id, user_id);
            CREATE TABLE IF NOT EXISTS disha_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                role TEXT NOT NULL, content TEXT NOT NULL, ts REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_disha_hist_user ON disha_history (guild_id, user_id, id);
            """
        )
        await self._db.commit()
        async with self._db.execute(
                "SELECT guild_id, enabled, channels, voice, gif, personality, chance FROM disha_config") as cur:
            for gid, en, chans, voice, gif, pers, chance in await cur.fetchall():
                self.cfgs[gid] = Cfg(gid, bool(en), {int(c) for c in chans.split(",") if c.strip().isdigit()},
                                     bool(voice), bool(gif), pers or "", int(chance))

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None

    # ----------------------------------------------------------------- config
    def cfg(self, guild_id: int) -> Cfg:
        c = self.cfgs.get(guild_id)
        if c is None:
            c = self.cfgs[guild_id] = Cfg(guild_id)
        return c

    async def save_cfg(self, c: Cfg) -> None:
        self.cfgs[c.guild_id] = c
        async with self._lock:
            await self._db.execute(
                "INSERT INTO disha_config (guild_id, enabled, channels, voice, gif, personality, chance) "
                "VALUES (?,?,?,?,?,?,?) ON CONFLICT(guild_id) DO UPDATE SET enabled=excluded.enabled, "
                "channels=excluded.channels, voice=excluded.voice, gif=excluded.gif, "
                "personality=excluded.personality, chance=excluded.chance",
                (c.guild_id, int(c.enabled), ",".join(str(i) for i in sorted(c.channels)),
                 int(c.voice), int(c.gif), c.personality, int(c.chance)))
            await self._db.commit()

    async def reset_cfg(self, guild_id: int) -> None:
        self.cfgs.pop(guild_id, None)
        async with self._lock:
            await self._db.execute("DELETE FROM disha_config WHERE guild_id=?", (guild_id,))
            await self._db.commit()

    # ------------------------------------------------------------ long memory
    async def add_facts(self, guild_id: int, user_id: int, facts: Iterable[str]) -> int:
        n = 0
        now = time.time()
        async with self._lock:
            for fact in facts:
                key = _norm(fact)
                if not key:
                    continue
                cur = await self._db.execute(
                    "INSERT INTO disha_facts (guild_id, user_id, fact, fkey, ts) VALUES (?,?,?,?,?) "
                    "ON CONFLICT(guild_id, user_id, fkey) DO UPDATE SET ts=excluded.ts",
                    (guild_id, user_id, fact, key, now))
                n += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
            # keep the table small: drop the least used / oldest facts beyond the cap
            await self._db.execute(
                "DELETE FROM disha_facts WHERE guild_id=? AND user_id=? AND id NOT IN ("
                "SELECT id FROM disha_facts WHERE guild_id=? AND user_id=? ORDER BY uses DESC, ts DESC LIMIT ?)",
                (guild_id, user_id, guild_id, user_id, MAX_FACTS_PER_USER))
            await self._db.commit()
        return n

    async def facts(self, guild_id: int, user_id: int) -> list[tuple[int, str, float, int]]:
        async with self._db.execute(
                "SELECT id, fact, ts, uses FROM disha_facts WHERE guild_id=? AND user_id=? ORDER BY ts DESC",
                (guild_id, user_id)) as cur:
            return [tuple(r) for r in await cur.fetchall()]

    async def touch(self, ids: list[int]) -> None:
        if not ids:
            return
        async with self._lock:
            await self._db.executemany("UPDATE disha_facts SET uses = uses + 1 WHERE id=?", [(i,) for i in ids])
            await self._db.commit()

    # ----------------------------------------------------------- short memory
    async def add_turn(self, guild_id: int, user_id: int, role: str, content: str) -> None:
        async with self._lock:
            await self._db.execute(
                "INSERT INTO disha_history (guild_id, user_id, role, content, ts) VALUES (?,?,?,?,?)",
                (guild_id, user_id, role, content[:600], time.time()))
            await self._db.execute(
                "DELETE FROM disha_history WHERE guild_id=? AND user_id=? AND id NOT IN ("
                "SELECT id FROM disha_history WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT ?)",
                (guild_id, user_id, guild_id, user_id, MAX_HISTORY_PER_USER))
            await self._db.commit()

    async def recent_turns(self, guild_id: int, user_id: int, n: int = 6,
                           max_age: float = 6 * 3600) -> list[tuple[str, str]]:
        async with self._db.execute(
                "SELECT role, content, ts FROM disha_history WHERE guild_id=? AND user_id=? "
                "ORDER BY id DESC LIMIT ?", (guild_id, user_id, n)) as cur:
            rows = await cur.fetchall()
        now = time.time()
        return [(r, c) for r, c, ts in reversed(rows) if now - ts <= max_age]

    # ------------------------------------------------------------- management
    async def clear_user(self, guild_id: int, user_id: int) -> int:
        async with self._lock:
            cur = await self._db.execute(
                "DELETE FROM disha_facts WHERE guild_id=? AND user_id=?", (guild_id, user_id))
            n = cur.rowcount or 0
            await self._db.execute(
                "DELETE FROM disha_history WHERE guild_id=? AND user_id=?", (guild_id, user_id))
            await self._db.commit()
        return n

    async def clear_guild(self, guild_id: int) -> int:
        async with self._lock:
            cur = await self._db.execute("DELETE FROM disha_facts WHERE guild_id=?", (guild_id,))
            n = cur.rowcount or 0
            await self._db.execute("DELETE FROM disha_history WHERE guild_id=?", (guild_id,))
            await self._db.commit()
        return n

    async def stats(self, guild_id: int) -> tuple[int, int]:
        async with self._db.execute("SELECT COUNT(*), COUNT(DISTINCT user_id) FROM disha_facts WHERE guild_id=?",
                                    (guild_id,)) as cur:
            row = await cur.fetchone()
        return int(row[0]), int(row[1])
