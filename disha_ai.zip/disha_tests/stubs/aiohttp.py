class ClientError(Exception): pass
class ClientTimeout:
    def __init__(self, total=None): self.total = total
class ClientSession: pass
class FormData:
    def __init__(self): self.fields = []
    def add_field(self, name, value, **kw): self.fields.append((name, value, kw))
