"""Test shim: aiosqlite API on top of sqlite3 (the sandbox has no aiosqlite)."""
import sqlite3

class _Cur:
    def __init__(self, cur): self._c = cur; self.rowcount = cur.rowcount
    async def fetchone(self): return self._c.fetchone()
    async def fetchall(self): return self._c.fetchall()
    def __await__(self):
        async def _(): return self
        return _().__await__()
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False

class _Exec:
    def __init__(self, conn, sql, args): self.conn, self.sql, self.args = conn, sql, args
    def __await__(self):
        async def _(): return _Cur(self.conn.execute(self.sql, self.args))
        return _().__await__()
    async def __aenter__(self): return _Cur(self.conn.execute(self.sql, self.args))
    async def __aexit__(self, *a): return False

class Connection:
    def __init__(self, path): self.conn = sqlite3.connect(path)
    def execute(self, sql, args=()): return _Exec(self.conn, sql, args)
    async def executescript(self, s): self.conn.executescript(s)
    async def executemany(self, sql, seq): self.conn.executemany(sql, seq)
    async def commit(self): self.conn.commit()
    async def close(self): self.conn.close()
    def __await__(self):
        async def _(): return self
        return _().__await__()
    async def __aenter__(self): return self
    async def __aexit__(self, *a): self.conn.close(); return False

def connect(path): return Connection(path)
