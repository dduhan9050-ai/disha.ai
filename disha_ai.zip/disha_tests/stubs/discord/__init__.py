class HTTPException(Exception): pass
class Forbidden(HTTPException): pass
class AllowedMentions:
    @classmethod
    def none(cls): return cls()
class Message: pass
class Member: pass
class TextChannel: pass
from . import abc
