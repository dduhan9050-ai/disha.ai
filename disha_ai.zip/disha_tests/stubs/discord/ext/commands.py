class Context: pass
class Cog:
    def __init_subclass__(cls, **kw): pass
    @staticmethod
    def listener(*a, **k):
        return lambda f: f
class _Cmd:
    def __init__(self, f, kw): self.f, self.kw, self.subs = f, kw, {}
    def command(self, **kw):
        def d(f):
            c = _Cmd(f, kw); self.subs[kw.get("name", f.__name__)] = c; return c
        return d
    def group(self, **kw): return self.command(**kw)
    def __call__(self, *a, **k): return self.f(*a, **k)
def group(**kw): return lambda f: _Cmd(f, kw)
def command(**kw): return lambda f: _Cmd(f, kw)
def has_permissions(**kw): return lambda f: f
def guild_only(): return lambda f: f
