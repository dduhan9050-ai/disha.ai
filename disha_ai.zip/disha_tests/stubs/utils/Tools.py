def blacklist_check(): return lambda f: f
def ignore_check(): return lambda f: f
async def get_ignore_data(gid): return {"user": [], "channel": []}
