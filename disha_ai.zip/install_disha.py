#!/usr/bin/env python3
"""Installs the Disha AI module into the DEATH DEVELOPMENT bot.

    python3 install_disha.py [path/to/botfast]        (default: ~/V50/botfast)

What it does (nothing else is touched, every edited file gets a .pre_disha backup):
  1. copies cogs/disha/ into the bot
  2. registers the cog in cogs/__init__.py inside a try/except (a Disha problem can never stop the other cogs)
  3. adds a "Disha AI" section to the Utility help category
  4. appends the Disha settings (empty) to .env if they are not there yet
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
root = os.path.abspath(os.path.expanduser(sys.argv[1] if len(sys.argv) > 1 else "~/V50/botfast"))


def die(msg):
    sys.exit("ERROR: " + msg)


def backup(path):
    bak = path + ".pre_disha"
    if not os.path.exists(bak):
        shutil.copy(path, bak)


def compile_ok(path):
    subprocess.check_call([sys.executable, "-m", "py_compile", path])


init = os.path.join(root, "cogs", "__init__.py")
if not os.path.isfile(init):
    die(f"{init} not found - pass the bot folder, e.g. python3 install_disha.py ~/V50/botfast")

# 1) files ---------------------------------------------------------------------------------------------
src, dst = os.path.join(HERE, "cogs", "disha"), os.path.join(root, "cogs", "disha")
os.makedirs(dst, exist_ok=True)
for name in sorted(os.listdir(src)):
    if name.endswith(".py"):
        shutil.copy(os.path.join(src, name), os.path.join(dst, name))
        compile_ok(os.path.join(dst, name))
print("1/4 cogs/disha copied")

# 2) register ------------------------------------------------------------------------------------------
text = open(init, encoding="utf-8").read()
if "from .disha import Disha" in text:
    print("2/4 already registered")
else:
    anchor = "async def setup(bot: axon):"
    if text.count(anchor) != 1:
        die("could not find `async def setup(bot: axon):` in cogs/__init__.py (nothing was changed)")
    block = (
        "# --- Disha AI companion (independent module; a failure here never blocks other cogs) ---\n"
        "try:\n"
        "    from .disha import Disha\n"
        "    _COGS.append(Disha)\n"
        "except Exception as _disha_err:\n"
        "    print(Fore.RED + Style.BRIGHT + f\"Disha AI not loaded: {type(_disha_err).__name__}: {_disha_err}\")\n\n\n"
    )
    backup(init)
    open(init, "w", encoding="utf-8").write(text.replace(anchor, block + anchor))
    compile_ok(init)
    print("2/4 registered in cogs/__init__.py")

# 3) help menu -----------------------------------------------------------------------------------------
helpcat = os.path.join(root, "cogs", "utility", "helpcat.py")
if not os.path.isfile(helpcat):
    print("3/4 (Utility help file not found - skipped)")
else:
    t = open(helpcat, encoding="utf-8").read()
    i = t.find("SECTIONS = (")
    e = t.find("\n)\n", i)
    if '"Disha AI"' in t:
        print("3/4 help section already there")
    elif i < 0 or e < 0:
        print("3/4 (could not find SECTIONS in helpcat.py - skipped, Disha works without it)")
    else:
        add = ('\n    ("Disha AI", [\n        "disha", "disha enable", "disha disable", "disha channel", "disha channel add",\n'
               '        "disha channel remove", "disha channel list", "disha personality", "disha voice", "disha gif",\n'
               '        "disha chance", "disha status", "disha mood", "disha memory", "disha forget",\n'
               '        "disha forgetall", "disha reset"]),')
        backup(helpcat)
        open(helpcat, "w", encoding="utf-8").write(t[:e] + add + t[e:])
        compile_ok(helpcat)
        print("3/4 Utility help section added")

# 4) .env ----------------------------------------------------------------------------------------------
env = os.path.join(root, ".env")
cur = open(env, encoding="utf-8").read() if os.path.isfile(env) else ""
if "DISHA_API_KEY" in cur:
    print("4/4 .env already has Disha settings")
else:
    with open(env, "a", encoding="utf-8") as f:
        f.write(("\n" if cur and not cur.endswith("\n") else "") +
                "\n# --- Disha AI companion ---\n"
                "# Any OpenAI-compatible provider. Default is Groq (free key: console.groq.com). GROQ_API_KEY also works.\n"
                "DISHA_API_KEY=\n"
                "# DISHA_API_BASE=https://api.groq.com/openai/v1\n"
                "# DISHA_MODEL=llama-3.3-70b-versatile\n"
                "# DISHA_STT_MODEL=whisper-large-v3-turbo\n"
                "# DISHA_MAX_CONCURRENCY=4\n"
                "# GIPHY_API_KEY=   (already used by the bot; needed for Disha's GIFs)\n")
    print("4/4 .env: Disha settings appended (fill DISHA_API_KEY)")

# checks -----------------------------------------------------------------------------------------------
print("\nChecks:")
for mod in ("aiohttp", "aiosqlite", "gtts"):
    try:
        __import__(mod)
        print(f"  ok       python module {mod}")
    except Exception:
        print(f"  MISSING  python module {mod}  -> pip install {'gTTS' if mod == 'gtts' else mod}")
print("  " + ("ok       " if shutil.which("ffmpeg") else "MISSING  ") + "ffmpeg (needed for voice replies)"
      + ("" if shutil.which("ffmpeg") else "  -> sudo apt install -y ffmpeg"))
print("\nNext: put your key in .env (DISHA_API_KEY=...), then  sudo systemctl restart deathbot  and run  .disha enable")
